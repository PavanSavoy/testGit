#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0xa3e2ce57, "struct_module" },
	{ 0xc4f25546, "device_destroy" },
	{ 0xdd132261, "printk" },
	{ 0x2f147475, "class_unregister" },
	{ 0xee46d0b9, "class_create" },
	{ 0xed9a0029, "device_create" },
	{ 0x7dee8ec9, "sock_register" },
	{ 0xe5dd62ea, "register_chrdev" },
	{ 0x62737e1d, "sock_unregister" },
	{ 0x9ef749e2, "unregister_chrdev" },
	{ 0x3be1d0ad, "class_destroy" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "F13BE55EABD6C4CC8FFA41E");
