#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/device.h>

#include <linux/firmware.h>
#include <linux/tty.h>

#define DEVICE_NAME "shuart"
#ifdef _use_cdev_
dev_t shudev; 
struct cdev *shu_cdev;
#endif
struct class *shuart_class;
int shuart_major;
const struct firmware *fw_entry;
static char shuart_buffer[250]; 

static void firmware_banthu_callback(const struct firmware *fw, void *context)
{
	printk("shuart: %s called \n", __FUNCTION__);
	return;
}


int shuart_chr_open(struct inode *inod, struct file *fil)
{
	int err;
	printk("shuart: %s called \n", __FUNCTION__);
/*	err = request_firmware_nowait(THIS_MODULE, FW_ACTION_HOTPLUG, "firmware.bin", NULL,
		NULL, firmware_banthu_callback);
*/

	return 0;
}

int shuart_chr_release(struct inode *inod, struct file *fil)
{
	printk("shuart: %s called \n", __FUNCTION__);
	return 0;
}

ssize_t shuart_chr_read(struct file *fil, char __user *data, size_t size, loff_t offset)
{
	printk("shuart: %s called \n", __FUNCTION__);
	memcpy(data, shuart_buffer, size);
	return 0;
}

ssize_t shuart_chr_write(struct file *fil, char __user *data, size_t size, loff_t offset)
{
	printk("shuart: %s called \n", __FUNCTION__);
	return 0;
}

struct file_operations shuart_chr_ops = {
	.owner = THIS_MODULE,
	.open = shuart_chr_open,
	.read = shuart_chr_read,
	.write = shuart_chr_write,
	.release = shuart_chr_release,
};


/* internal functions */
static int shuart_tty_open(struct tty_struct *tty)
{
        printk("shuart: %s: \n", __FUNCTION__);
	return 0;
}
static void shuart_tty_close(struct tty_struct *tty)
{
        printk("shuart: %s: \n", __FUNCTION__);
        return;
}
/*
 * We don't provide read/write/poll interface for user space.
 */
#if 0
static ssize_t shuart_tty_read(struct tty_struct *tty, struct file *file,
                unsigned char __user *buf, size_t nr)
{
        printk("shuart: %s: \n", __FUNCTION__);
        return 0;
}
#endif

static ssize_t shuart_tty_write(struct tty_struct *tty, struct file *file,
                const unsigned char *data, size_t count)
{
        printk("shuart: %s: \n", __FUNCTION__);
	tty->driver->write(tty, data, count);
        return 0;
}
/*
static unsigned int shuart_tty_poll(struct tty_struct *tty,struct file *filp, poll_table *wait)
{
        printk("shuart: %s: \n", __FUNCTION__);
        return 0;
}
*/
/* ioctl function -
 * none of ioctl are intended for shuart pass onto hci_ldisc
 */
static int shuart_tty_ioctl(struct tty_struct *tty, struct file * file,unsigned int cmd, unsigned long arg)
{
        printk("shuart: %s: \n", __FUNCTION__);
	return 0;
}

/* receive function
 * important to decide upon which protocol's event handler be called
 */
static void shuart_tty_receive(struct tty_struct *tty, const u8 *data, char *flags, int count)
{
	int i=0;
        printk("shuart: %s: \n", __FUNCTION__);
	printk("shuart: %d bytes \n", count);
	for (i=0; i<count; i++)
		printk("shuart: data %c \n", data[i]);
	memcpy(shuart_buffer, data, count);
}

void populate_line_discipline(struct tty_ldisc *shuart_ldisc_ops)
{
        shuart_ldisc_ops->magic            = TTY_LDISC_MAGIC;
        shuart_ldisc_ops->name             = "n_shuart"; /*"n_hci";*/
        /*
         * decide upon name - because hciattach/other utils would still make
         * use of n_hci
         */
        shuart_ldisc_ops->open             = shuart_tty_open;
        shuart_ldisc_ops->close            = shuart_tty_close;
/*        shuart_ldisc_ops->read             = shuart_tty_read;
        shuart_ldisc_ops->write            = shuart_tty_write;
*/
        shuart_ldisc_ops->ioctl            = shuart_tty_ioctl;
/*        shuart_ldisc_ops->poll             = shuart_tty_poll;*/
        shuart_ldisc_ops->receive_buf      = shuart_tty_receive;
/*        shuart_ldisc_ops->write_wakeup     = shuart_tty_wakeup;*/
        shuart_ldisc_ops->owner            = THIS_MODULE;
}

static int __init chrdev_init(void)
{
	int err=0;
        /* line discipline for TTY */
        static struct tty_ldisc shuart_ldisc_ops;
	
#ifdef _use_cdev_
/* chrdev region */
	err = alloc_chrdev_region(&shudev, 0, 1, DEVICE_NAME);
	printk("shuart: %d: allocated %d, %d\n", err, MAJOR(shudev), MINOR(shudev));
	err = register_chrdev_region(&shudev, 0, DEVICE_NAME);
	printk("shuart: err is %d \n", err);
/* cdev */

	shu_cdev = cdev_alloc();
	shu_cdev->ops = &shuart_chr_ops;
	shu_cdev->owner = THIS_MODULE;

	shuart_major = MAJOR(shudev);	
	err = cdev_add(shu_cdev, shudev, 0);
	printk("shuart: cdev added %d\n", err);
#else
	shuart_major = register_chrdev(0, DEVICE_NAME, &shuart_chr_ops);	
	printk("shuart: %d: allocated %d, %d\n", err, shuart_major, 0);
#endif
/*  udev */
	shuart_class = class_create(THIS_MODULE, DEVICE_NAME);
	if (IS_ERR(shuart_class))
		printk("shuart: something went wrong in class_create\n");
#ifdef _use_cdev_
	device_create(shuart_class, NULL, MKDEV(MAJOR(shudev), MINOR(shudev)), NULL, DEVICE_NAME);
#else
//	device_create(shuart_class, NULL, MKDEV(shuart_major, 0), NULL, DEVICE_NAME);
	device_create(shuart_class, NULL, MKDEV(shuart_major, 0), DEVICE_NAME);
#endif
#if 0
	err = request_firmware(&fw_entry, "ti_5052.fw"/*"firmware.bin"*/, DEVICE_NAME);
	if (err != 0)
	{
		printk("shuart: something went wrong...in request_firmware \n");
	}
#endif
/* line discipline ops */
        memset(&shuart_ldisc_ops, 0, sizeof(shuart_ldisc_ops));
        populate_line_discipline(&shuart_ldisc_ops);
        if ((err=tty_register_ldisc(N_SHARED, &shuart_ldisc_ops)))
        {
                printk(KERN_ERR"shuart:error registering line discipline\n");
        }
        printk(KERN_INFO "shuart: registered to n_shared line discipline\n");
	return 0;
}

static void __exit chrdev_exit(void)
{
	int err=0;
	printk("shuart: bye.. freeing up %d\n", shuart_major);
	device_destroy(shuart_class, MKDEV(shuart_major, 0));
	class_unregister(shuart_class);
	class_destroy(shuart_class);
#ifdef _use_cdev
	cdev_del(shu_cdev);
	unregister_chrdev_region(&shudev, 0);
#else
	unregister_chrdev(shuart_major, DEVICE_NAME);
#endif
/*
	release_firmware(fw_entry);
*/
/* release ldisc ops */
        if ((err=tty_unregister_ldisc(N_SHARED)))
                printk(KERN_ERR"shuart: unable to un-register line discipline\n");
}

module_init(chrdev_init);
module_exit(chrdev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Pavan Savoy");
