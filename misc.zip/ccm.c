#include <termios.h> 
#include <unistd.h>

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <syslog.h>
#include <termios.h>
#include <time.h>
#include <sys/time.h>
#include <sys/poll.h>
#include <sys/param.h>
#include <linux/ioctl.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/uio.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>

#define UART_DEVICE	"/dev/ttyUSB0"
#define N_SHARED	13
#define _my_cmd_opcode_pack(ogf, ocf)  (uint16_t)((ocf & 0x03ff)|(ogf << 10))

char g_buffer[10];
int length_to_write;
int dev_fd;

int _my_recvmsg(int dd)
{
        char    recv_buffer[20]={0}; int r=-1, i=0;

	 printf("reading from device \n");
        r = read(dd, &recv_buffer[0], 2);
        if (recv_buffer[0] == 0x08)
                printf(" received %d bytes on chan %d!! \n", recv_buffer[1], recv_buffer[0]);
        else
                printf(" %x %x \n", recv_buffer[0], recv_buffer[1]);

        r = read(dd, &recv_buffer[2], recv_buffer[1]);

	 for (i=2; i<recv_buffer[1]+2; i++)
                printf(" %x ", recv_buffer[i]);

        printf("\n");
        return 0;
}

int _my_hci_send_cmd(int dd, int opt)
{
	/*      
	 * unsigned short buffer[]={0x08, 0x03f, 0x0fd35, 0x18, 0x0000};
	 */      
	//need to first power-on in chan_8 mode to get data
	unsigned char p_type; //buffer[0]; //HCI_COMMAND_PKT;
	struct iovec iv[3];
	int ivn, plen=1, len=0;
	hci_command_hdr hc;

	p_type = 0x08;

	while (len = write(dd, g_buffer, length_to_write)) 
	{
                if (errno == EAGAIN || errno == EINTR)
                        continue;
                return -1;
        }
	
        printf("sent %d bytes \n", len);
        return 0;
}



int fill_buffer(const char *file_name)
{
	int fd=-1;      
	int len=-1, count=-1, i=0;
	char str_buffer[100]={0}, *ptr;

	fd = open(file_name, O_RDONLY);
	if (fd<0) 
	{
		printf("error opening file\n");
		return -1;
	}

	len = read(fd, str_buffer, 100);
	printf(" bytes read from file: %d \n", len);

	sscanf(str_buffer, "%d", &count);
	ptr = str_buffer;       
	ptr+=2; 
	printf(" bytes to write: %d \n", count);

	for (i=0; i<count; i++) 
	{
		sscanf(ptr, "0x%02x", &g_buffer[i]);
		printf(" data to write -- 0x%x \n", g_buffer[i]);
		ptr+=5; //for data and space fields
	}

	length_to_write = count;
	return 0;

}

int ccm_init()
{
	int  i;
	struct termios ti;

	dev_fd = open(UART_DEVICE, O_RDWR | O_NOCTTY);

	if (dev_fd < 0) 
	{
		printf("CCM:Can't open %s\n",UART_DEVICE);
		return -1;
	}

	tcflush(dev_fd, TCIOFLUSH);

	if (tcgetattr(dev_fd, &ti) < 0) 
	{
		printf("CCM:Can't get port settings\n");
		return -1;
	}	
		
	cfmakeraw(&ti);

	ti.c_cflag |= 1;
	ti.c_cflag |= CRTSCTS;

	tcsetattr(dev_fd, TCSANOW, &ti);
	cfsetospeed(&ti, B115200);
	cfsetispeed(&ti, B115200);
	tcsetattr(dev_fd, TCSANOW, &ti);
#if 0
	i = N_SHARED;
	if (ioctl(dev_fd, TIOCSETD, &i) < 0) {
		perror("Can't set line discipline");
		return -1;
	}
#endif
	printf(" 1. line discipline %d \n", i);
	i = -1;
/*	close(dev_fd);
	dev_fd = open(UART_DEVICE, O_RDWR | O_NOCTTY);

	if (dev_fd < 0) 
	{
		printf("CCM:Can't open %s\n",UART_DEVICE);
		return -1;
	}

	if (ioctl(dev_fd, TIOCGETD, &i) < 0) {
               perror("Can't set line discipline");
               return -1;
        }
*/	printf(" 2. line discipline %d \n", i);

	close(dev_fd);
	return 0;
}

void send_cmd()
{
	fill_buffer("/home/read_fw");
	_my_hci_send_cmd(dev_fd, 0);
	_my_recvmsg(dev_fd);
}

#define HCIUARTSETPROTO         _IOW('U', 200, int)

int install_proto()
{
	int shuart_fd = open("/dev/shuart", O_RDWR);
	printf("ccm: shuart_fd = %d, %x\n", shuart_fd, HCIUARTSETPROTO);

	if (ioctl(shuart_fd, HCIUARTSETPROTO, 4 /*HCI_UART_LL*/) < 0) {
		perror("\nCan't set device\n");
		return -1;
	}
	close(shuart_fd);
}


int main()
{
	printf("\n In main()\n");
	if(ccm_init() < 0)
	{
		fprintf(stderr,"CCM: ccm_init failed!!!\n");
		return 0;
	}
	else
	{	
		fprintf(stderr,"CCM: ccm_init passed. . .\n");
		while(1)
		{
			sleep(10);
		}
		//send_cmd();
	}

	/*if(install_proto() < 0)
	{
		fprintf(stderr,"CCM: install_proto failed!!\n");
                return 0;
        }
        else
        {
                fprintf(stderr,"CCM: install_proto passed. . .\n");
        }*/
               
	return 1;
}












