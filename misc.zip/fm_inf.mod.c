#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0xa3e2ce57, "struct_module" },
	{ 0xf70bd2a2, "shuart_sock_proto_register" },
	{ 0xf557f1a6, "shuart_sock_proto_unregister" },
	{ 0xf0e354b3, "sock_init_data" },
	{ 0x51f2f31f, "sk_alloc" },
	{ 0xdd132261, "printk" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=chrdev";


MODULE_INFO(srcversion, "CBE8929902926E290502BA0");
