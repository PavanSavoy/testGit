#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/device.h>

#include <linux/firmware.h>
#include <net/sock.h>

#include "proto_inf.h"

#define DEVICE_NAME "shuart"

#ifdef _use_cdev_
dev_t shudev; 
struct cdev *shu_cdev;
#endif
struct class *shuart_class;
int shuart_major;
const struct firmware *fw_entry;

static struct net_proto_family *shuart_protos[SHUART_PROTO_MAX];

static void firmware_banthu_callback(const struct firmware *fw, void *context)
{
	printk("shuart: %s called \n", __FUNCTION__);
	return;
}


int shuart_chr_open(struct inode *inod, struct file *fil)
{
	int err;
	printk("shuart: %s called \n", __FUNCTION__);
/*	err = request_firmware_nowait(THIS_MODULE, FW_ACTION_HOTPLUG, "firmware.bin", NULL,
		NULL, firmware_banthu_callback);
*/

	return 0;
}

int shuart_chr_release(struct inode *inod, struct file *fil)
{
	printk("shuart: %s called \n", __FUNCTION__);
	return 0;
}

ssize_t shuart_chr_read(struct file *fil, char __user *data, size_t size, loff_t offset)
{
	printk("shuart: %s called \n", __FUNCTION__);
	return 0;
}

ssize_t shuart_chr_write(struct file *fil, char __user *data, size_t size, loff_t offset)
{
	printk("shuart: %s called \n", __FUNCTION__);
	return 0;
}

struct file_operations shuart_chr_ops = {
	.owner = THIS_MODULE,
	.open = shuart_chr_open,
	.read = shuart_chr_read,
	.write = shuart_chr_write,
	.release = shuart_chr_release,
};


static int shuart_sock_create(struct net *net, struct socket *sock, int proto)
{
	int err=-1;
	printk("shuart: %s \n", __FUNCTION__);

	err = shuart_protos[proto]->create(net, sock, proto);
	printk("shuart: sock_create: err bantha ? %d \n", err);
	return 0;
}

static struct net_proto_family shuart_sock_family_ops = {
	.owner = THIS_MODULE,
	.family = PF_SHUART,
	.create = shuart_sock_create,
};


int shuart_sock_proto_register(int proto, struct net_proto_family *ops)
{
	printk("shuart: proto->ops now called \n");
	shuart_protos[proto] = ops;
	return 0;
}
EXPORT_SYMBOL(shuart_sock_proto_register);

int shuart_sock_proto_unregister(int proto)
{
	printk("shuart: proto->ops now nulled \n");
	shuart_protos[proto] = NULL;
	return 0;
}
EXPORT_SYMBOL(shuart_sock_proto_unregister);

static int __init chrdev_init(void)
{
	int err=0;
#ifdef _use_cdev_
/* chrdev region */
	err = alloc_chrdev_region(&shudev, 0, 1, DEVICE_NAME);
	printk("shuart: %d: allocated %d, %d\n", err, MAJOR(shudev), MINOR(shudev));
	err = register_chrdev_region(&shudev, 0, DEVICE_NAME);
	printk("shuart: err is %d \n", err);
/* cdev */

	shu_cdev = cdev_alloc();
	shu_cdev->ops = &shuart_chr_ops;
	shu_cdev->owner = THIS_MODULE;

	shuart_major = MAJOR(shudev);	
	err = cdev_add(shu_cdev, shudev, 0);
	printk("shuart: cdev added %d\n", err);
#else
	shuart_major = register_chrdev(0, DEVICE_NAME, &shuart_chr_ops);	
	printk("shuart: %d: allocated %d, %d\n", err, shuart_major, 0);
#endif
/*  udev */
	shuart_class = class_create(THIS_MODULE, DEVICE_NAME);
	if (IS_ERR(shuart_class))
		printk("shuart: something went wrong in class_create\n");
#ifdef _use_cdev_
	device_create(shuart_class, NULL, MKDEV(MAJOR(shudev), MINOR(shudev)), NULL, DEVICE_NAME);
#else
/*	device_create(shuart_class, NULL, MKDEV(shuart_major, 0), NULL, DEVICE_NAME);*/
	device_create(shuart_class, NULL, MKDEV(shuart_major, 0), DEVICE_NAME);
#endif
#if 0
	err = request_firmware(&fw_entry, "ti_5052.fw"/*"firmware.bin"*/, DEVICE_NAME);
	if (err != 0)
	{
		printk("shuart: something went wrong...in request_firmware \n");
	}
#endif
/* socket interface */
	err = sock_register(&shuart_sock_family_ops);
	printk("shuart: sock_register .. err is %d\n", err);
	return 0;
}

static void __exit chrdev_exit(void)
{
	printk("shuart: bye.. freeing up %d\n", shuart_major);
	
	sock_unregister(PF_SHUART);
	device_destroy(shuart_class, MKDEV(shuart_major, 0));
	class_unregister(shuart_class);
	class_destroy(shuart_class);
#ifdef _use_cdev
	cdev_del(shu_cdev);
	unregister_chrdev_region(&shudev, 0);
#else
	unregister_chrdev(shuart_major, DEVICE_NAME);
#endif
/*
	release_firmware(fw_entry);
*/
}

module_init(chrdev_init);
module_exit(chrdev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Pavan Savoy");
