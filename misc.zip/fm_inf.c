#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/device.h>

#include <linux/firmware.h>
#include <net/sock.h>

#include "proto_inf.h"

static int fm_sock_bind(struct socket *sock, struct sockaddr *addr, int addr_len)
{
	printk("fm_inf: sock_bind: \n");
	return 0;
}

static int fm_sock_release(struct socket *sock)
{
	printk("fm_inf: sock_release: \n");
	return 0;
}

static const struct proto_ops fm_sock_ops = {
	.family = AF_SHUART,
	.owner = THIS_MODULE,
	.bind = fm_sock_bind,
	.release = fm_sock_release,
};

struct fm_pinfo {
	char namma_buffer[4];
};

static struct proto fm_sk_proto = {
	.name = "FM",
	.owner = THIS_MODULE,
	.obj_size = sizeof(struct fm_pinfo),
};

static int fm_sock_create(struct net *net, struct socket *sock, int proto)
{
	struct sock *sk;
	printk("fm_inf: %s \n", __FUNCTION__);

	printk("fm_inf: sock type: %d\n", sock->type);
	sock->ops = &fm_sock_ops;

	sk = sk_alloc(net, PF_SHUART, GFP_ATOMIC, &fm_sk_proto);
	if (!sk)
		printk("fm_inf: sk_alloc err banthu \n");

	sk->sk_protocol = proto;
	sock_init_data(sock, sk);
	sock->state = SS_UNCONNECTED;

	return 0;
}

struct net_proto_family fm_proto_ops = {
	.owner = THIS_MODULE,
	.family = PF_SHUART,
	.create = fm_sock_create,
};

static int __init fm_inf_init(void)
{
	/* protocol register -- to be moved to fm,gps */
	shuart_sock_proto_register(SHUART_PROTO_FM, &fm_proto_ops);
	printk("fm_inf: sock proto registered \n");
	return 0;
}

static void __exit fm_inf_exit(void)
{
	shuart_sock_proto_unregister(SHUART_PROTO_FM);
	return;
}
module_init(fm_inf_init);
module_exit(fm_inf_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Pavan Savoy");
