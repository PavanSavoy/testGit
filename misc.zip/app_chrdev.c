#include <stdio.h>
#include <sys/socket.h>

#include "proto_inf.h"

int main(int argc, char **argv)
{
	int fd=-1;
	fd = socket(AF_SHUART, SOCK_RAW, SHUART_PROTO_FM);

	printf("app_chrdev: socket fd %d\n", fd);
	close(fd);
	return 0;
}
