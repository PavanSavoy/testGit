/**
 * tsc2007_platform.c
 * Platform specific file for the driver for Texas Instruments TSC2007 touchscreen
 * controller on I2C bus on AT91SAM9261 board.
 *
 * Author: Joseph Robert (joseph_robert@mindtree.com)
 * Date:   26-06-2008
 * */



#include <linux/init.h>
#include <linux/interrupt.h>
#include <asm/arch-at91/gpio.h>
#ifdef  CONFIG_ARM
#include <asm/mach-types.h>
#endif

/*
 * This Function returns the pen down state of the penirq pin
 * parameters:
 *	input:
 *		pin:irq number
 *	output:
 *		irq line status
 */

int pen_down_state (unsigned int pin)
{
	return !at91_get_gpio_value(pin);
}

/*  This Funtion detects the proper PENIRQ line.
 *  It return the GPIO line ID to which the PENIRQ is connected
 *  & sets the GPIO Line as input.
 * 
 *  parameters:
 *	output:
 *		irq number of the correspoding penirq.
 */

int tsc2007_detect_penirq (void)
{
	at91_set_gpio_input (AT91_PIN_PB0,1);
	return AT91_PIN_PB0;
}
