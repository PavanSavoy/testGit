/**
 * tsc2007.h
 * Header file for the driver for Texas Instruments TSC2007 touchscreen
 * controller on I2C bus on AT91SAM9261 board.
 *
 * Author: Joseph Robert (joseph_robert@mindtree.com)
 * Date:   12-06-2008
 * */  

#ifndef _H_TSC2007
#define _H_TSC2007

#define DRIVER_NAME "TSC2007"
#define AT91

#define VALIDATE_ALL_COMMANDS
#define SETUP_MAV_RIRQ
#define REPORT_ACTUAL_PRESSURE

#ifdef AT91
#include <asm/arch-at91/gpio.h>
#define USE_PULLUP 1
#endif

/* debug macros */

#define dbg_tsc(format, arg...)\
	printk(KERN_DEBUG format, ## arg)

#define alert_tsc(format, arg...)\
	printk(KERN_ALERT format, ## arg)



/* command byte */ 

#define TSC2007_CMD(cmd,pdn,m) (((cmd) << 4) | ((pdn) << 2) | ((m) << 1))


/* set up command */

#ifdef SETUP_MAV_RIRQ
#define TSC2007_SETUP_CMD(mav,rirq) ((0xb0)  | ((mav) << 1) | ((rirq) ))

/* filter control */

#define USE_MAV 	0
#define BYPASS_MAV 	1

/* Rirq value */

#define RIRQ_50KOHMS	0
#define RIRQ_90KOHMS	1

#define USE_MAV_RIRQ_50KOHMS TSC2007_SETUP_CMD(USE_MAV,RIRQ_50KOHMS) 
#define USE_MAV_RIRQ_90KOHMS TSC2007_SETUP_CMD(USE_MAV,RIRQ_90KOHMS) 
#define BYPASS_MAV_RIRQ_50KOHMS TSC2007_SETUP_CMD(BYPASS_MAV,RIRQ_50KOHMS) 
#define BYPASS_MAV_RIRQ_90KOHMS TSC2007_SETUP_CMD(BYPASS_MAV,RIRQ_90KOHMS) 

/*  
 *  NOTE::The tsc2007 driver has a default set up setting of
 *  USE_MAV_RIRQ_50KOHMS. 
 *  CAUTION: The Rirq value of 90Kohms is a weak pullup and may lead
 *  to inconsistent results.
 */
#define CURRENT_SETUP_SETTING USE_MAV_RIRQ_50KOHMS
#endif


/* Use M_12BIT for 12 bit resolution and M_8BIT for 8 bit resolution */

#define BIT_MODE_12
#ifndef BIT_MODE_12
#define BIT_MODE_8
#endif	

#ifdef BIT_MODE_12
#define ADC_MAX 4096
#define VALUE_MASK 0XFFF
#else
#define ADC_MAX 256
#define VALUE_MASK 0XFF
#endif

#define ADC_PRESSURE_MAX 150000
#define FIXED_PRESSURE_VAL 7500
#define RX_PLATE_VAL 450
#define PRESSURE_FALSE 0
#define TOUCH_FALSE 0
#define TOUCH_TRUE 1


#define START_TIMER_DELAY 5
#define RESTART_TIMER_DELAY 5
#define BYTES_TO_TX 1

#ifdef BIT_MODE_12
#define BYTES_TO_RX 2
#else	 
#define BYTES_TO_RX 1
#endif	 

#define ENABLE_DEGLITCH 1
#define DISABLE_DEGLITCH 0

/*Define the screen size if not defined*/
#ifndef CONFIG_INPUT_MOUSEDEV_SCREEN_X
#define CONFIG_INPUT_MOUSEDEV_SCREEN_X 320
#endif

#ifndef CONFIG_INPUT_MOUSEDEV_SCREEN_Y
#define CONFIG_INPUT_MOUSEDEV_SCREEN_Y 240
#endif

/*
#define LCD_X_MAX 240
#define LCD_Y_MAX 320
*/
/* converter functions */

enum converter_function 
{ 
	MEAS_TEMP0 = 0, 
	MEAS_AUX = 2, 
	MEAS_TEMP1 = 4, 
	ACTIVATE_X_DRIVERS =8, 
	ACTIVATE_Y_DRIVERS = 9, 
	ACTIVATE_YnX_DRIVERS = 10, 
	MEAS_XPOS = 12, 
	MEAS_YPOS = 13, 
	MEAS_Z1 = 14, 
	MEAS_Z2 = 15 
};

enum power_down_mode 
{ 
	PD_POWERDOWN_ENABLEPENIRQ = 0, /* ADC off & penirq */ 
	PD_ADCON_DISABLEPENIRQ = 1, /* ADC on & no penirq */ 
};

/* resolution modes */

enum resolution_mode 
{ 
	M_12BIT = 0, 
	M_8BIT = 1 
};

/*Function declarations*/ 

static int tsc2007_attach(struct i2c_adapter *adapter);
static int tsc2007_detach(struct i2c_client *client);
u8 pen_down_state (unsigned int  pin);
int tsc2007_detect_penirq (void);


#endif	
