/*
 * This file contains the platform dependent
 * code for the TSC 2005 driver
 */
#include <linux/init.h>
#include <linux/interrupt.h>
#include <asm/arch-at91/gpio.h>
#include <asm/mach-types.h>


/* 
 * This along with tsc2005_detect_irq are the functions which 
 * are platform specific.
 * Return the line status PENIRQ here.
 * @params:
 *	output:
 *		line status of /PENIRQ
 */
int tsc2005_pendown_state(void)
{
	return at91_get_gpio_value(AT91_PIN_PB0);
}

/*
 * Configure PB0 as the PENIRQ
 * The function should return the IRq to which PENIRQ 
 * 	of TSC is connected.
 * @params:
 *	input:
 *		data: tsc2005_data structure
 *	output:
 *		function return status
 */
int tsc2005_detect_irq(void)
{
	at91_set_gpio_input(AT91_PIN_PB0, 1);
	at91_set_deglitch(AT91_PIN_PB0, 1);

	return AT91_PIN_PB0;
}
