/*
 * tsc2008.h. Header file for the Texas Instruments TSC2008 touchscreen
 * controller on the SPI bus on AT91SAM9261 board.
 *
 * Author: Shubhro Sinha
 * Date:   10-06-2008
 * */

#ifndef _H_TSC2008
#define _H_TSC2008

/*#define BIT_MODE_12*/
#define BIT_MODE_8
/* Uncomment the follwoing line
 * if you do not want to use the
 * MAV filter*/

#define DISABLE_MAV_FILTER
#define USE_90K_RIRQ
#define REPORT_ACTUAL_PRESSURE

#ifdef BIT_MODE_12
#define ADC_MAX 4096
#define RESOLUTION_MODE M_12BIT
#define VALUE_MASK 0xFFF
#define BYTES_TO_RX 2
#elif defined (BIT_MODE_8)
#define ADC_MAX 256
#define RESOLUTION_MODE M_8BIT
#define VALUE_MASK 0xFF
#define BYTES_TO_RX 1
#else
#define BIT_MODE_8
#define ADC_MAX 256
#define RESOLUTION_MODE M_8BIT
#define BYTES_TO_RX 1
#define VALUE_MASK 0xFF
#warning No resolution mode specified. Using the 8 bit resolution mode
#endif

#define IGNORE_MSB 1

/*TSC2008 setup command*/
#define TSC2008_SETUP(pullup,mav_bypass,timing,rst) ((0xA<<4)|(pullup<<3)\
	|(mav_bypass<<2)|(timing<<1)|(rst));

/*TSC2008 commands except setup command*/
#define TSC2008_CTRL(chn_select,mode,ser_dfr,pnd1,pnd0) ((0x1<<7)|\
	(chn_select<<4)|(mode<<3)|(ser_dfr<<2)|(pnd1<<1)|(pnd0))

#define ADC_PRESSURE_MAX 15000
#define FIXED_PRESSURE_VAL 128

#define START_TIMER_DELAY 3
#define RESTART_TIMER_DELAY 2

#ifndef CONFIG_INPUT_MOUSEDEV_SCREEN_X
#define CONFIG_INPUT_MOUSEDEV_SCREEN_X 320
#endif

#ifndef CONFIG_INPUT_MOUSEDEV_SCREEN_Y
#define CONFIG_INPUT_MOUSEDEV_SCREEN_Y 240
#endif

#ifdef USE_90K_RIRQ
#define PULLUP_RIRQ 1
#else
#define PULLUP_RIRQ 0
#endif

#define DFR 0
#define SFR 1

#if defined DISABLE_MAV_FILTER
#define SWITCH_MAV 1
#else
#define SWITCH_MAV 0
#endif

#define DEFAULT_TIMING 0
#define RESET_FALSE 0
#define RESET_TRUE 1

#define BYTES_TO_TX 1
#define PND_0 0

#define SPI_BITS_PER_WORD 8

#if !defined (DISABLE_MAV_FILTER) && defined (BIT_MODE_12)
#define XFER_DELAY 100
#elif !defined (DISABLE_MAV_FILTER) && defined  (BIT_MODE_8)
#define XFER_DELAY 50
#else
#define XFER_DELAY 10
#endif

#define RX_PLATE_VAL 450
enum convertor_function 
{
	MEAS_TEMP_1,	/*Measure Tempe 1:	0x1*/
	MEAS_Y_POS,	/*Measure Y position:	0x2*/
	SETUP_CMD,	/*Set up command:	0x3*/
	MEAS_Z1_VAL,	/*Measure Z1 value:	0x4*/
	MEAS_Z2_VAL,	/*Measure Z2 value:	0x5*/
	MEAS_X_POS,	/*Measure X Position:	0x6*/
	MEAS_AUX,	/*Measure Auxillary input:	0x7*/
	MEAS_TEMP_2	/*Measure Tempe2	:0x8*/
};

enum resolution_mode 
{
	M_12BIT,	/*12 bit resolution mode*/
	M_8BIT		/*8 bit resolution mode*/
};

int pen_down_state (unsigned int  pin);
int tsc2008_detect_penirq (void);
#endif
