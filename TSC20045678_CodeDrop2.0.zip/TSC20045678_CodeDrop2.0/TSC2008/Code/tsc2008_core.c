/* *
 * tsc2008.c. Driver for Texas Instruments TSC2008 touchscreen
 * controller on SPI bus on AT91SAM9261 board.
 * This file contains the platform independent code 
 * Author: Shubhro Sinha <shubhro_sinha@mindtree.com>
 * MindTree Limited 
 * Date:   10-06-2008
 * */

#include <linux/hwmon.h>
#include <linux/init.h>
#include <linux/err.h>
#include <linux/delay.h>
#include <linux/input.h>
#include <linux/interrupt.h>
#include <linux/slab.h>
#include <linux/spi/spi.h>
#include <asm/irq.h>
#include "tsc2008.h"

/*The TSC2008 data structure*/
struct tsc2008_data {
	/*The input device*/
	struct input_dev *idev;
	struct spi_device *spi;
	struct timer_list timer;
	struct spi_message msg[6];
	struct spi_transfer xfer[12];
	int pen_irq;
	spinlock_t lock;
	/*The X,Y,Z1,Z2 read commands*/
	u8 read_x;
	u8 read_y;
	u8 read_z1;
	u8 read_z2;
	/*Results of X,Y,Z1 and Z2 reads*/
	u16 x_pos;
	u16 y_pos;
	u16 z1_val;
	u16 z2_val;
	u8  msg_idx;
};


/**
 * Final completion handler. Collates all the values and
 * reports to the input subsystem
 * @params:
 * 	input:
 * 		data: tsc2008_data structure 
 **/

static void tsc2008_report (void *data)
{
	struct tsc2008_data *ts = (struct tsc2008_data*)data;
	u16 tmp;
	u16 pressure_val = FIXED_PRESSURE_VAL;
#ifdef REPORT_ACTUAL_PRESSURE
	u32 factor;
#endif
	
 	/**
	 * The values coming out of the TSC2008 are in big-endian format and 
	 * ****NEED BYTE SWAPPING***** on little endian machines. Depending 
	 * upon values can be used. Also X and Y values need to be swapped for
	 * use with the  X window system. Driver authors be careful. NO 
	 * SWAPPING required for 8 bit mode. Also the left most bit received 
	 * is an ignore bit
	 **/

#ifdef BIT_MODE_8
	/* *
	 * Swap the X and Y coordinates. Leave out the MUST ignore bit
	 * and then mask of the bits greater than 12
	 * */
	tmp = ts->y_pos;
	ts->y_pos =   (ts->x_pos << IGNORE_MSB) &VALUE_MASK;
	ts->x_pos =   (tmp << IGNORE_MSB) &VALUE_MASK;
	ts->z1_val =  (ts->z1_val << IGNORE_MSB) &VALUE_MASK;
	ts->z2_val =  (ts->z2_val << IGNORE_MSB) & VALUE_MASK;
#elif defined (BIT_MODE_12)
	/* *
	 * Swap the X and Y coorsinates. Leave out the MUST ignore bit.
	 * Make the resulting value into an 8 bit value
	 * */
	ts->x_pos = ((be16_to_cpu (ts->x_pos) << IGNORE_MSB) >> 4) & VALUE_MASK;
	ts->y_pos = ((be16_to_cpu (ts->y_pos) << IGNORE_MSB) >> 4) & VALUE_MASK;
	ts->z1_val = ((be16_to_cpu (ts->z1_val) << IGNORE_MSB) >> 4) & VALUE_MASK;
	ts->z2_val = ((be16_to_cpu (ts->z2_val) << IGNORE_MSB) >> 4) & VALUE_MASK;

	tmp = ts->x_pos;
	ts->x_pos = ts->y_pos;
	ts->y_pos = tmp;
#else
#error Invalid mode selection
#endif
	/* *
	 * Scale the coordinates for GPE. Other applications might 
	 * not require scaling
	 * Driver authors be careful.
	 * */

	ts->x_pos = ((ADC_MAX-ts->x_pos)*CONFIG_INPUT_MOUSEDEV_SCREEN_Y)/ADC_MAX;
	ts->y_pos = (CONFIG_INPUT_MOUSEDEV_SCREEN_X*ts->y_pos)/ADC_MAX;

#ifdef REPORT_ACTUAL_PRESSURE
	if (ts->z1_val)	{
		factor = (ts->z2_val/ts->z1_val -1)*ts->y_pos*RX_PLATE_VAL;
		factor/=ADC_MAX;
		pressure_val = factor & VALUE_MASK;
	}
#endif
	/*Report the read coordinates to the input subsystem */
	input_report_abs (ts->idev,ABS_X,ts->x_pos);
	input_report_abs (ts->idev,ABS_Y,ts->y_pos);
	input_report_abs (ts->idev,ABS_PRESSURE,pressure_val);
	input_report_key (ts->idev,BTN_TOUCH,1);
	input_sync (ts->idev);

	ts->msg_idx = 0;

	/*Check for prolonged touches i.e drags and drawings */
	if (pen_down_state(ts->pen_irq) )
	{
		mod_timer (&ts->timer,jiffies + RESTART_TIMER_DELAY);
	}
	else
	{
		input_report_abs (ts->idev,ABS_PRESSURE,0);
		input_report_key (ts->idev,BTN_TOUCH,0);
		input_sync (ts->idev);
		enable_irq (ts->pen_irq);
	}
	return;
}

/**
 * SPI interim completion handler. Submit the commands
 * to read X,Y,Z1 and Z2 respectively on successive calls.
 * @params:
 * 	input:
 * 		data: tsc2008_data structure
 **/

static  void  tsc2008_spi_again_submit (void *data)
{
	struct tsc2008_data *ts = (struct tsc2008_data*)data;
	struct spi_message *m;
	struct spi_transfer *t;
	
	spin_lock (&ts->lock);
	m = &ts->msg [ts->msg_idx];
	t = list_entry (m->transfers.prev,struct spi_transfer,transfer_list);

	ts->msg_idx++;
	m = &ts->msg [ts->msg_idx];
	spi_async (ts->spi,m);
	spin_unlock (&ts->lock);
	return;
}

/**
 * TSC2008 timer funtion. Called whenever
 * PENIRQ is low.
 * @params:
 *	input:
 * 		arg: tsc2008_data structure 
 **/

static void tsc2008_timer (unsigned long arg)
{
	struct tsc2008_data *data = (struct tsc2008_data*)arg;
	int stat;

	spin_lock_irq (&data->lock);

	/*Check whether pen has gone up*/
	if ( !pen_down_state (data->pen_irq) )
	{
		input_report_abs (data->idev,ABS_PRESSURE,0);
		input_report_key (data->idev,BTN_TOUCH,0);
		input_sync (data->idev);
		enable_irq (data->pen_irq);
	}
	else
	{
		data->msg_idx = 0;
		stat = spi_async (data->spi,&data->msg[0]);
		if (stat)
			dev_err (&data->spi->dev,"spi_async----> %d\n",stat);
	}

	spin_unlock_irq (&data->lock);
	return;
}

/**
 * IRQ handler for the PENIRQ.
 * @params:
 * 	input:
 * 		irq: IRQ number
 * 		v: tsc2008_data structure
 *	output:
 *		IRQ handled status
 * */
static irqreturn_t tsc2008_handle_penirq (int irq, void *v)
{
	struct tsc2008_data *data = (struct tsc2008_data*)v;
	unsigned long flags;

	/*Start timer if pen is down*/
	spin_lock_irqsave (&data->lock,flags);
	if (likely (pen_down_state (data->pen_irq))) {
		disable_irq (irq);
		mod_timer (&data->timer,jiffies + 3);
	}

	spin_unlock_irqrestore (&data->lock,flags);
	return IRQ_HANDLED;
}


/**
 * Function to setup the spi message list
 * @params:
 * 	input:
 * 		data: struct tsc2008_data
 **/
static void tsc2008_spi_setup (struct  tsc2008_data *data)
{
	struct spi_message *m;
	struct spi_transfer *x;
	
	x = &data->xfer[0];
	m = &data->msg[0];

	/* Set up the SPI message for reading X */
	spi_message_init (m);
	memset (x,0,sizeof(*x));
	x->tx_buf = &data->read_x;
	x->len = BYTES_TO_TX;
	x->delay_usecs = XFER_DELAY;
	spi_message_add_tail (x,m);


	x++;
	memset (x,0,sizeof(*x));
	x->rx_buf = &data->x_pos;
	x->len = BYTES_TO_RX;
	spi_message_add_tail (x,m);

	m->complete = tsc2008_spi_again_submit;
	m->context = data;

	/* Set up the SPI message for reading X */
	m++;
	x++;

	spi_message_init (m);
	x->tx_buf = &data->read_y;
	x->len = BYTES_TO_TX;
	x->delay_usecs = XFER_DELAY;
	spi_message_add_tail (x,m);

	x++;
	memset (x,0,sizeof(*x));
	x->rx_buf = &data->y_pos;
	x->len = BYTES_TO_RX;
	spi_message_add_tail (x,m);

	m->complete= tsc2008_spi_again_submit;
	m->context = data;
	
	/* Set up the SPI message for reading Z1 */
	x++;
	m++;

	spi_message_init (m);
	memset (x,0,sizeof(*x));
	x->tx_buf = &data->read_z1;
	x->len = BYTES_TO_TX;

	x->delay_usecs = XFER_DELAY;
	spi_message_add_tail (x,m);

	x++;
	memset (x,0,sizeof(*x));
	x->rx_buf = &data->z1_val;
	x->len = BYTES_TO_RX;

	spi_message_add_tail (x,m);

	m->complete = tsc2008_spi_again_submit;
	m->context = data;

	/* Set up the SPI message for reading Z2 */
	x++;
	m++;
	
	spi_message_init (m);
	memset (x,0,sizeof(*x));
	x->tx_buf = &data->read_z2;
	x->len = BYTES_TO_TX;

	x->delay_usecs = XFER_DELAY;
	spi_message_add_tail (x,m);

	x++;
	memset (x,0,sizeof(*x));

	x->rx_buf = &data->z2_val;
	x->len = BYTES_TO_RX;

	spi_message_add_tail (x,m);

	/**
	 * Final reporting. Set the completion handler
	 * to report the values to the input subsystem
	 **/
	m->complete = tsc2008_report;
	m->context = data;
	return ;

}

 /**
  * SPI probe. Detects and registers the spi slave device
  *	@params:
  *	input:
  *		The SPI structure
  *	output:
  *		function exit status		
  **/
static int __devinit tsc2008_probe(struct spi_device *spi)
{
	struct tsc2008_data *data;
	struct input_dev *idev;
	int stat;
	u8 tx_buf = 0;


	spi->bits_per_word = SPI_BITS_PER_WORD;
	spi->mode = SPI_MODE_0;
	
	stat = spi_setup(spi);

	if (stat) {
		goto err_return;
	}

	data = kzalloc(sizeof(*data), GFP_KERNEL);
	if (!data) {
		stat = -ENOMEM;
		goto err_return;
	}

	data->spi = spi;

	/*Set up the read X,Y,Z1 and Z2 commands*/
	data->read_x = TSC2008_CTRL(MEAS_X_POS,RESOLUTION_MODE,
			DFR,PND_0,PND_0);
	data->read_y = TSC2008_CTRL(MEAS_Y_POS,RESOLUTION_MODE,
			DFR,PND_0,PND_0);
	data->read_z1 = TSC2008_CTRL(MEAS_Z1_VAL,RESOLUTION_MODE,
			DFR,PND_0,PND_0);
	data->read_z2 = TSC2008_CTRL(MEAS_Z2_VAL,RESOLUTION_MODE,
			DFR,PND_0,PND_0);


	idev = input_allocate_device();
	if (!idev) {
		stat = -ENOMEM;
		goto err_free_mem;
	}

	dev_set_drvdata(&spi->dev, data);
	data->spi = spi;
	data->idev = idev;

	idev->name = "TSC2008 Touchscreen";
	idev->dev.parent = &spi->dev;
	idev->evbit[0] = BIT_MASK(EV_KEY) | BIT_MASK(EV_ABS);
	idev->keybit[BIT_WORD(BTN_TOUCH)] = BIT_MASK(BTN_TOUCH);

	input_set_abs_params(idev, ABS_X, 0, ADC_MAX, 0, 0);
	input_set_abs_params(idev, ABS_Y, 0, ADC_MAX, 0, 0);
	input_set_abs_params(idev, ABS_PRESSURE, 0, ADC_PRESSURE_MAX, 0, 0);

	data->pen_irq = tsc2008_detect_penirq();

	dev_info(&spi->dev, "touchscreen, irq %d\n", data->pen_irq);

	stat = input_register_device(idev);

	if (stat) {
		dev_dbg(&spi->dev, "unable to register input device\n");
		goto err_free_mem;
	}

	init_timer (&data->timer);
	data->timer.function = tsc2008_timer;
	data->timer.data = (unsigned long)data;


	tsc2008_spi_setup (data);

	stat = request_irq(data->pen_irq, tsc2008_handle_penirq,
			   IRQF_TRIGGER_FALLING, "tsc2008", data);

	if (stat) {
		dev_dbg(&spi->dev, "%d irq busy\n", data->pen_irq);
		goto err_free_idev;
	}

	/*Reset the controller once*/
	tx_buf  = TSC2008_SETUP(PULLUP_RIRQ,SWITCH_MAV,DEFAULT_TIMING,
			RESET_TRUE);
	if ((stat=spi_write (spi,&tx_buf,BYTES_TO_TX)))
		goto err_free_idev;
#if defined (USE_90K_RIRQ) || defined (DISABLE_MAV_FILTER)
	/* *
	 * Send the set up command if controller is to be 
	 * configured differently
	 * */
	tx_buf  = TSC2008_SETUP(PULLUP_RIRQ,SWITCH_MAV,DEFAULT_TIMING,
			RESET_FALSE);
	if ((stat=spi_write (spi,&tx_buf,BYTES_TO_TX)))
		goto err_free_idev;
#endif
	
	return 0;
err_return:
	return stat;
err_free_mem:
	kfree(data);
	return stat;
err_free_idev:
	input_unregister_device (data->idev);
	kfree (data);
	return stat;
}

/*
 * Unregister the device.
 *	@params:
 * 	input:
 *		The SPI device
 *	output:
 *		The exit status
 */
static int __devexit tsc2008_remove (struct spi_device *spi)
{
	struct tsc2008_data *data = dev_get_drvdata (&spi->dev);

	input_unregister_device (data->idev);
	free_irq (data->pen_irq,data);
	kfree (data);

	dev_dbg (&spi->dev,"unregister touchscreen\n");

	return 0;
}

/* The SPI driver structure*/
static struct spi_driver tsc2008_driver = {
	.driver = {
		   .name = "tsc2008",
		   .bus = &spi_bus_type,
		   .owner = THIS_MODULE,
		   },
	.probe = tsc2008_probe,
	.remove = __devexit_p(tsc2008_remove)
};

static int __init tsc2008_init(void)
{
	return spi_register_driver(&tsc2008_driver);
}

static void __exit tsc2008_exit(void)
{
	spi_unregister_driver(&tsc2008_driver);
}

module_init(tsc2008_init);
module_exit(tsc2008_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Shubhro Sinha; Report bugs to <shubhro_sinha@mindtree.com");
MODULE_DESCRIPTION("Driver for the SPI TSC2008 controller");
