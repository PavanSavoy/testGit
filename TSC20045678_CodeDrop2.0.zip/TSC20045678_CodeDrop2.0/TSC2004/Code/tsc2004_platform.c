/* *
 * tsc2004_platform.c. Driver for Texas Instruments TSC2004 touchscreen
 * controller on I2C bus on AT91SAM9261 board.
 * This file contains the platform dependent code
 * Author: Shubhro Sinha <shubhro_sinha@mindtree.com>
 * MindTree Limited 
 * Date:   26-06-2008
 * */
#include <linux/init.h>
#include <linux/interrupt.h>
#include <asm/arch-at91/gpio.h>
#ifdef CONFIG_ARM
#include <asm/mach-types.h>
#endif

/* *
 *  Detect the proper PENIRQ line.
 *  In this case configure PB0 as pen_irq. 
 *  @params
 * 	output:
 *		function returns the IRQ number
 * */
int tsc2004_detect_irq(void)
{
	/*Set PB0 as GPIO input and as the IRQ line */
	at91_set_gpio_input(AT91_PIN_PB0, 1);
	return AT91_PIN_PB0;
}

/* *
 * Checks the IRQ line state
 * @params:
 * input:
 *	pin: The IRQ number
 * */
int pen_down_state(unsigned int pin)
{
	return !at91_get_gpio_value (pin);
}
