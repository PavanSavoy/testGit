/* *
 * tsc2004_core.c. Driver for Texas Instruments TSC2004 touchscreen
 * controller on I2C bus on AT91SAM9261 board.
 * This file contains the platform independent code.
 * Author: Shubhro Sinha <shubhro_sinha@mindtree.com>
 * MindTree Limited 
 * Date:   15-05-2008
 * */

#include <linux/init.h>
#include <linux/err.h>
#include <linux/input.h>
#include <linux/delay.h>
#include <linux/input.h>
#include <linux/interrupt.h>
#include <linux/slab.h>
#include <linux/i2c.h>
#include <linux/byteorder/generic.h>
#include <linux/timer.h>
#include <linux/jiffies.h>
/*
 *	Header file also has the configuration/build options
 */
#include "tsc2004.h"

static unsigned int short
 normal_i2c[] = { 0x48, I2C_CLIENT_END };

I2C_CLIENT_INSMOD_1(tsc2004);

static struct i2c_driver tsc2004_driver = {
	.driver = {
		   .owner = THIS_MODULE,
		   .name = "tsc2004",
		   },

	.attach_adapter = tsc2004_attach,
	.detach_client = tsc2004_detach,
};
/** 
 * Driver Data Structure 
 **/
struct tsc2004_data {
	/*An i2c client,timer and an input device*/
	struct i2c_client client;
	struct timer_list timer;
	struct input_dev *idev;
	/*The IRQ number*/
	unsigned int pen_irq;
};


/* *
 * Timer function. Called when touch is detected
 * @params:
 * 	input:
 * 		arg: struct tsc2004_data structure
 * */
static void tsc2004_timer(unsigned long arg)
{
	struct tsc2004_data *data = (struct tsc2004_data *)arg;
	struct i2c_client *client = &data->client;
	u16 value_mask = 0;
	u32 stat = 0;
	u16 kernel_x = 0, kernel_y = 0;
	u16 reg_values [REG_SET_SIZE];
	u8 tx_buffer = 0;
	u16 pressure_val = 0;
#ifdef REPORT_ACTUAL_PRESSURE
	s32 factor = 0;
#endif

#if (!defined (TSMode1) && !defined (TSMode2)) ||\
	(defined (TSMode1) && defined (TSMode2))
#define TSMode1
#warning No mode/Multiple modes selected. Selected TSMode1
#endif

#if defined (TSMode2)
	/*Send the convertor function to the TSC2004 controller */
	tx_buffer = TSC2004_CMD1(MEAS_Y_X_Z1_Z2, RESOLUTION_MODE, RESET_FALSE);

	stat = i2c_master_send(client, &tx_buffer, TX_BUFFER_BYTES_1);
	if (stat != TX_BUFFER_BYTES_1) {
		dev_warn(&client->dev, "Unable to send convertor function\n");
	}
#endif
	/*Send command to read X register */
	tx_buffer = TSC2004_CMD0(X_REG, PND0_FALSE, READ_REG);
	stat = i2c_master_send(client, &tx_buffer, TX_BUFFER_BYTES_1);
	if (stat != TX_BUFFER_BYTES_1) {
		dev_warn(&client->dev, "Unable to read X command\n");
	}

	/* *
	 * Use the sequential read cycle of the TSC2004 to read 
	 * back the registers
	 * */
	stat = i2c_master_recv(client, (u8 *) reg_values, REG_BUF_BYTES);

	/* *
	 * Now we have the contents of the entire regiseter 
	 * set in the reg_values array in the sequence mentioned 
	 * in the data sheet. viz.
	 * reg_values [0] = X measurement result
	 * reg_values [1] = Y measurement value
	 * ..... and so on.
	 * */

	if (stat != REG_BUF_BYTES) {
		dev_warn(&client->dev, "unable to fetch register values\n");
	}
#ifdef BIT_MODE_10
	value_mask = 0x3FF;	/*10 bit resolution */
#elif defined (BIT_MODE_12)
	value_mask = 0xFFF;	/*12 bit resolution */
#else
#error "Invalid Resolution"
#endif

	/* *
	 * The values coming out of the TSC2004 are in big-endian format and 
	 * ****NEED BYTE SWAPPING***** on little endian machines. Depending upon
	 * values can be used. Also X and Y values need to be swapped for 
	 * use with the  X window system. Driver authors be careful.
	 * */

	kernel_x = be16_to_cpu(reg_values[1]) & value_mask;
	kernel_y = be16_to_cpu(reg_values[0]) & value_mask;

	/* *
	 * Scale the coordinates for GPE. Other applications might 
	 * not require scaling
	 * Driver authors be careful.
	 * */
	kernel_x = ((ADC_MAX - kernel_x) * CONFIG_INPUT_MOUSEDEV_SCREEN_Y) / ADC_MAX;
	kernel_y = (CONFIG_INPUT_MOUSEDEV_SCREEN_X * kernel_y) / ADC_MAX;

	/*Report the read coordinates to the input subsystem */

#ifdef REPORT_ACTUAL_PRESSURE

	/* *
	 * Use values from reg_values to calculate the pressure
	 * and report the same.
	 * */
	if (be16_to_cpu(reg_values[2]) & value_mask) {
		factor =
		    (((be16_to_cpu(reg_values[3]) & value_mask) /
		      (be16_to_cpu(reg_values[2]) & value_mask)) - 1);
		factor *=
		    (RX_PLATE_VAL * (be16_to_cpu(reg_values[0]) & value_mask));
		factor /= ADC_MAX;
		pressure_val = factor & value_mask;
	} else {
		/**  Got Z1 = 0 for some reason
		 *   Better report some fixed pressure value
		 *   instead of failing to report pressure.
		 **/
		pressure_val = FIXED_PRESSURE_VAL;
	}

#else
	pressure_val = FIXED_PRESSURE_VAL;
#endif


	/*Check for prolonged touches i.e drags and drawings */
#if defined PENIRQ_PINTDAV_OUTPUT
	/* Check the IRQ line as well as the DAV bits in the STATUS reg to avoid false clicks*/
	if (pen_down_state(data->pen_irq) || (be16_to_cpu(reg_values [7]) & 0xF000) > 0) {
		/*Report the X,Y,Z1,Z2 inside so as to avoid false clicks*/
		input_report_abs(data->idev, ABS_X, kernel_x);
		input_report_abs(data->idev, ABS_Y, kernel_y);
		input_report_abs(data->idev, ABS_PRESSURE, pressure_val);

		input_report_key(data->idev, BTN_TOUCH, TOUCH_TRUE);
		input_sync(data->idev);
		mod_timer(&data->timer, jiffies + RESTART_TIMER_DELAY);
	} else {
		enable_irq(data->pen_irq);
	}
#else
	/*Report the X,Y,and pressure values*/
	input_report_abs(data->idev, ABS_X, kernel_x);
	input_report_abs(data->idev, ABS_Y, kernel_y);
	input_report_abs(data->idev, ABS_PRESSURE, pressure_val);
	input_report_key(data->idev, BTN_TOUCH, TOUCH_TRUE);
	input_sync(data->idev);


	if (pen_down_state(data->pen_irq)) {
		mod_timer(&data->timer,jiffies + RESTART_TIMER_DELAY);
	} else {
		enable_irq (data->pen_irq);
	}
#endif
	return;

}

/*The handler for the penirq
 * @params:
 *	input:
 * 		irq: The irq number
 * 		v: struct tsc2004_data
 *	output:
 		IRQ handled status
 **/
static irqreturn_t tsc2004_handle_penirq(int irq, void *v)
{
	struct tsc2004_data *data = (struct tsc2004_data *)v;

	disable_irq(data->pen_irq);

	/*Start timer when the touch is detected */
	if (pen_down_state(data->pen_irq)) {
		mod_timer(&data->timer, jiffies + START_TIMER_DELAY);
	} else {
		/*Pen off. Report to the input subsystem */
		input_report_key(data->idev, BTN_TOUCH, TOUCH_FALSE);
		input_report_abs(data->idev, ABS_PRESSURE, PRESSURE_FALSE);
		input_sync(data->idev);
		enable_irq(data->pen_irq);
	}
	return IRQ_HANDLED;
}

/* *
 * Register the the TSC2004 to the kernel. Allocate a input device,
 * request IRQs and finally register.
 * @params:
 * 	input:
 * 		data: tsc2004_data structure
 *	output:
 		function exit status
 * */
static int tsc2004_register_driver(struct tsc2004_data *data)
{
	struct input_dev *idev;
	struct i2c_client *client = &data->client;

	int ret;

	data->pen_irq = tsc2004_detect_irq();
	
	dev_info(&client->dev, "touchscreen, irq %d\n", data->pen_irq);

	init_timer(&data->timer);
	data->timer.function = &tsc2004_timer;
	data->timer.data = (unsigned int)data;

	idev = input_allocate_device();

	if (idev == NULL) {
		dev_err(&client->dev, "Unable to allocate input device\n");
		return -ENOMEM;
	}

	idev->name = DRIVER_NAME;
	idev->private = data;
	idev->dev.parent = &((data->client).dev);
	idev->evbit[0] = BIT_MASK(EV_ABS) | BIT_MASK(EV_KEY);
	idev->keybit[BIT_WORD(BTN_TOUCH)] = BIT_MASK(BTN_TOUCH);
	idev->absbit[BIT_WORD(ABS_X)] = BIT_MASK(ABS_X);
	idev->absbit[BIT_WORD(ABS_Y)] = BIT_MASK(ABS_Y);
	idev->absbit[BIT_WORD(ABS_PRESSURE)] = BIT_MASK(ABS_PRESSURE);

	/* *
	 * Tell the input subsystem the range of values that our controller
	 * can send.
	 * */
	input_set_abs_params(idev, ABS_X, 0, ADC_MAX, 0, 0);
	input_set_abs_params(idev, ABS_Y, 0, ADC_MAX, 0, 0);
	input_set_abs_params(idev, ABS_PRESSURE, 0, ADC_PRESSURE_MAX, 0, 0);

	data->idev = idev;

	dev_info(&client->dev, "registering input device\n");
	if (input_register_device(data->idev)) {
		dev_err(&client->dev,
			"Unable to register input device: %s", __FUNCTION__);
		goto err_exit;
	}

	ret =
	    request_irq(data->pen_irq, tsc2004_handle_penirq,
			IRQF_TRIGGER_FALLING, DRIVER_NAME, data);

	if (ret) {
		dev_dbg(&client->dev, "%d irq busy\n", data->pen_irq);
		goto err_exit;
	}
	return 0;

err_exit:
	return -ENODEV;
}

/**
 * i2c_detect function. Called by i2c_probe
 *	@params:
 *		input: Global structure adapter(defined in linux/i2c.h),
 *			i2c address and kind of probing(forceful detection)
 *		output:
 *			function exit status
 */
static int tsc2004_detect(struct i2c_adapter *adapter, int address, int kind)
{
	struct i2c_client *new_client;
	struct tsc2004_data *data = NULL;
	s32 err = 0;
	char *name = "tsc2004";
	u8 tx_buffer[TX_BUFFER_BYTES_3];

	tx_buffer[1] = tx_buffer[0] = tx_buffer[2] = 0;

	if (!i2c_check_functionality(adapter, I2C_FUNC_SMBUS_BYTE_DATA
				     | I2C_FUNC_I2C
				     | I2C_FUNC_SMBUS_WORD_DATA)) {
		err=-ENOSYS;
		goto err_exit;
	}

	data = kzalloc(sizeof(*data), GFP_KERNEL);

	if (NULL == data) {
		err = -ENOMEM;
		goto err_exit;
	}

	new_client = &data->client;
	i2c_set_clientdata(new_client, data);

	new_client->addr = address;
	new_client->adapter = adapter;
	new_client->driver = &tsc2004_driver;
	new_client->flags = 0;

	strlcpy(new_client->name, name, I2C_NAME_SIZE);

	/*Try probing...... Send a SOFTWARE RESET and wait for the ACK. If we have an
	   ack assume that its our device */


	tx_buffer[0] =
	    TSC2004_CMD1(MEAS_Y_X_Z1_Z2, RESOLUTION_MODE, RESET_TRUE);

	if ((TX_BUFFER_BYTES_1 !=
	     (err = i2c_master_send(new_client, tx_buffer, TX_BUFFER_BYTES_1)))) {
		goto err_exit;
	}

	/*Device found. Attach it to the I2C bus */

	if ((err = i2c_attach_client(new_client))) {
		dev_err(&new_client->dev,
			"%s: unable to attach device on : %#x\n",
			__FUNCTION__, address);
		goto err_exit;
	}

	err = tsc2004_register_driver(data);

	if (err)
		goto err_exit;
#ifdef PENIRQ_PINTDAV_OUTPUT
	/**
	 * Configure PINTDAV output as PENIRQ i.e PINTS1 = 1,
	 * PINTS0 = 0
	 **/

	tx_buffer [0] = TSC2004_CMD0(CFR2_REG,PND0_FALSE,WRITE_REG);
	tx_buffer [1] = 0x80;
	tx_buffer [2] = 0x00;

	err = i2c_master_send (new_client,tx_buffer,TX_BUFFER_BYTES_3);

	if (err != TX_BUFFER_BYTES_3) {
		dev_err (&new_client->dev,"unable to configure CFR2: %s\n",
				__FUNCTION__);
	}
#endif
#if defined(TSMode1)
	/** 
	 * Configure the TSC in TSMode 1. We donot need to configure
	 * the host controlled mode. By default the TSC2004 controller
	 * gets into host controlled mode
	 **/
	tx_buffer[0] = TSC2004_CMD0(CFR0_REG, PND0_FALSE, WRITE_REG);

	/** Set CFR0 as follows:
	 *  <---------------tx_buffer[0]------------------><---------------tx_buffer[1]------------------->
	 *  ---------------------------------------------------------------------------------------------
	 * | PSM | STS | RM | CL1 | CL0 | PV2 | PV1 | PV0 | PR2 | PR1 | PR0 | SN2 | SN1 | SN0 | DTW | LSM |  
	 * |  1     0     0    0     0     0     0     0     0     0     0     0     1     0     0     0  |
	 *  --------------------------------------------------------------------------------------------- 
	 **/
	tx_buffer[1] = 0x80;
#if defined(PENIRQ_PINTDAV_OUTPUT)
	tx_buffer[2] = 0x00;
#else
	tx_buffer[2] = 0x08;
#endif

	err = i2c_master_send(new_client, tx_buffer, TX_BUFFER_BYTES_3);

	if (err != TX_BUFFER_BYTES_3) {
		dev_err(&new_client->dev, "unable to configure CFR0: %s\n",
			__FUNCTION__);
		goto err_exit;
	}

	/* *
	 * Send the convertor functions.Only X , Y ,Z1 and Z2 
	 * conversion functions enabled. 
	 * */
	tx_buffer[0] =
	    TSC2004_CMD1(MEAS_Y_X_Z1_Z2, RESOLUTION_MODE, RESET_FALSE);

	err = i2c_master_send(new_client, tx_buffer, TX_BUFFER_BYTES_1);

	if (err != TX_BUFFER_BYTES_1) {
		dev_err(&new_client->dev, "unable to send scan mode: %s\n",
			__FUNCTION__);
		goto err_exit;
	}
#elif defined(TSMode2)

	/**
	 * No need to configure TSC. By default TSC is in TSMode2
	 * Just configure the sense time selection bits
	 **/
#ifndef PENIRQ_PINTDAV_OUTPUT
	tx_buffer[0] = TSC2004_CMD0(CFR0_REG, PND0_FALSE, WRITE_REG);

	/** Set CFR0 as follows:
	 *  <---------------tx_buffer[0]------------------><---------------tx_buffer[1]------------------->
	 *  ----------------------------------------------------------------------------------------------
	 * | PSM | STS | RM | CL1 | CL0 | PV2 | PV1 | PV0 | PR2 | PR1 | PR0 | SN2 | SN1 | SN0 | DTW | LSM |  
	 * |  0     0    0     0     0     0     0     0     0     0      0     1     0    0     0    1   |
	 *  ---------------------------------------------------------------------------------------------- 
	 * */
	tx_buffer[1] = 0x00;
	tx_buffer[2] = 0x09;

	err = i2c_master_send(new_client, tx_buffer, TX_BUFFER_BYTES_3);
	if (err != TX_BUFFER_BYTES_3) {
		dev_err(&new_client->dev, "unable to configure CFR0: %s\n",
			__FUNCTION__);
		goto err_exit;
	}
#endif
#else
#error "Invalid TSMode"
#endif

	return 0;

err_exit:
	kfree (data);
	return err;
}

/**
 *  Function to attach i2c client.
 * @params:
 *	adapter: The global adapter structure (defined in linux/i2c.h)
 */
static int tsc2004_attach(struct i2c_adapter *adapter)
{
	return i2c_probe(adapter, &addr_data, &tsc2004_detect);
}

/*
 *  Function to detach i2c client
 *  @params:
 *	client: The i2c_client device for our chip
 */
static int tsc2004_detach(struct i2c_client *client)
{
	int err = 0;

	struct tsc2004_data *data = i2c_get_clientdata(client);

	input_unregister_device(data->idev);
	input_free_device(data->idev);

	free_irq(data->pen_irq, data);

	del_timer_sync (&data->timer);

	if ((err = i2c_detach_client(client))) {
		return err;
	}

	kfree (data);
	return err;


}

static int __init tsc2004_init(void)
{
	return i2c_add_driver(&tsc2004_driver);
}

static void __exit tsc2004_exit(void)
{
	i2c_del_driver(&tsc2004_driver);
}

module_init(tsc2004_init);
module_exit(tsc2004_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Shubhro Sinha;Report bugs to shubhro_sinha@mindtree.com");
MODULE_DESCRIPTION("Driver for TSC2004 touch screen controller");
