/**
 * tsc2004.h. Header file for the driver for Texas Instruments TSC2004 touchscreen
 * controller on I2C bus on AT91SAM9261 board.
 *
 * Author: Shubhro Sinha
 * Date:   15-05-2008
 * */

#ifndef _H_TSC2004
#define _H_TSC2004

#define DRIVER_NAME "TSC2004"

#define TSMode1
/*#define TSmode2*/
#define BIT_MODE_12
/*#define BIT_MODE_10*/
#define REPORT_ACTUAL_PRESSURE

#define PENIRQ_PINTDAV_OUTPUT

#define TX_BUFFER_BYTES_1   1
#define TX_BUFFER_BYTES_3 3
#define REG_BUF_BYTES 32

#define TOUCH_TRUE  1
#define TOUCH_FALSE 0
#define RX_PLATE_VAL 450
#define PRESSURE_FALSE 0

#define RESET_TRUE  1
#define RESET_FALSE 0
#define READ_REG    1
#define WRITE_REG   0
#define PND0_TRUE   1
#define PND0_FALSE  0

#ifdef BIT_MODE_10
#define RESOLUTION_MODE M_10BIT
#elif defined (BIT_MODE_12)
#define RESOLUTION_MODE M_12BIT
#else
#warning No resolution specified. Using the 10bit resolution mode
#define BIT_MODE_10
#define RESOLUTION_MODE M_10BIT
#endif

/*TSC2004 control byte 0*/
#define TSC2004_CMD0(addr,pnd,rw) ((addr<<3)|(pnd<<1)|rw )
/*TSC2004 control byte 1*/
#define TSC2004_CMD1(cmd,mode,rst) ((1<<7)|(cmd<<4)|(mode<<2)|(rst<<1))

#ifdef BIT_MODE_10
#define ADC_MAX 1024
#elif defined (BIT_MODE_12)
#define ADC_MAX 4096
#else
#error "Invalid Resolution"
#endif

#define ADC_PRESSURE_MAX 15000
#define FIXED_PRESSURE_VAL 7500

#ifdef PENIRQ_PINTDAV_OUTPUT
#define START_TIMER_DELAY 3
#define RESTART_TIMER_DELAY 3
#else
#define START_TIMER_DELAY 5
#define RESTART_TIMER_DELAY 5
#endif

#define REG_SET_SIZE 16

/*Define the screen size if not defined*/
#ifndef CONFIG_INPUT_MOUSEDEV_SCREEN_X
#define CONFIG_INPUT_MOUSEDEV_SCREEN_X 320
#endif

#ifndef CONFIG_INPUT_MOUSEDEV_SCREEN_Y
#define CONFIG_INPUT_MOUSEDEV_SCREEN_Y 240
#endif

/*The TSC2004 convertor function mapping*/
enum convertor_function 
{
	MEAS_Y_X_Z1_Z2, /*Measure X,Y,z1 and Z2:	0x0*/
	MEAS_Y_X_POS, 	/*Measure X and Y only:		0x1*/
	MEAS_X_POS, 	/*Measure X only:		0x2*/
	MEAS_Y_POS,	/*Measure Y only:		0x3*/
	MEAS_Z1_Z2_POS, /*Measure Z1 and Z2 only:	0x4*/
	MEAS_AUX,	/*Measure Auxillary input:	0x5*/
	MEAS_TEMP1, 	/*Measure Temparature1:		0x6*/
	MEAS_TEMP2,	/*Measure Temparature2:		0x7*/
	MEAS_AUX_CONT,	/*Continuously measure Auxillary input: 0x8*/
	X_DRV_TEST,	/*X drivers tested*/
	Y_DRV_TEST,	/*Y drivers tested*/
	/*Command Reserved*/
	SHRT_CKT_TST = 0xC ,		/*Short circuit test*/
	X_PLUS_X_MINUS_DRV_STAT,	/*X+,Y- drivers status*/	
	Y_PLUS_Y_MINUS_DRV_STAT,	/*X+,Y- drivers status*/
	Y_PLUS_X_MINUS_DRV_STAT		/*Y+,X- drivers status*/
};

/*The TSC2004 register address mapping*/
enum register_address
{
	X_REG,	/*The X register:	0x0*/
	Y_REG,	/*The Y register:	0x1*/
	Z1_REG,	/*The Z1 register:	0x2*/
	Z2_REG,	/*The Z2 register:	0x3*/
	AUX_REG, /*The AUXILLARY register:0x4*/	
	TEMP1_REG,	/*The Temparature1 register:	0x5*/
	TEMP2_REG,	/*The Temparature2 register:	0x6*/
	STAT_REG,	/*The Status Register:		0x7*/
	AUX_HGH_TH_REG,	/*The AUXILLARY high threshold register:	0x8*/
	AUX_LOW_TH_REG,	/*The AUXILLARY low threshold register:		0x9*/
	TMP_HGH_TH_REG,	/*The Temparature high threshold register:	0xA*/
	TMP_LOW_TH_REG,	/*The Temparature low threshold register:	0xB*/
	CFR0_REG,	/*Configuration register 0:	0xC*/
	CFR1_REG,	/*Configuration register 1:	0xD*/
	CFR2_REG,	/*Configuration register 2:	0xE*/
	CFN_SEL_STAT	/*Convertor function select register:		0xF*/
};

/*TSC2004 resolution modes*/
enum resolution_mode 
{
	M_10BIT,	/*10 bit resolution*/
	M_12BIT		/*12 bit resolution*/
};

/*Function declarations*/
static int tsc2004_attach (struct i2c_adapter *adapter);
static int tsc2004_detach (struct i2c_client *client);
int tsc2004_detect_irq (void);
int pen_down_state (unsigned int pin);
#endif
