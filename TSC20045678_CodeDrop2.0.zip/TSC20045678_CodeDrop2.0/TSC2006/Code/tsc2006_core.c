/*
 *	Driver for TI Touch Screen Controller TSC2006 
 *	 
 * 
 * TSC Interfaced with Atmel AT91sam9261ek board,
 * with PENIRQ connected to AT91_PIN_PB0 and on
 * SPI0.2 (spi0 chip_select2)
 * modalias: "tsc2006"
 * 
 * 
 * Author	: Pavan Savoy (pavan_savoy@mindtree.com)
 * Date		: 15-05-2008
 */

/*
 *	Header file also has the configuration/build options
 */
#include "tsc2006.h"

/* 
 * Driver Data Structure 
 */
struct tsc2006 {
/* 
 * An SPI & an Input driver 
 */
	struct spi_device *spi_dev;
	struct input_dev *input_dev;
/* 
 * SPI message & transfer related data 
 */
	struct spi_transfer xfer[MAX_SPI_XFERS];
	struct spi_message msg[MAX_SPI_MSGS];
	int msg_idx;
/* 
 * X, Y, Z1, and Z2 positions - & ignore if required
 */
	u16 x_pos, y_pos, z1_pos, z2_pos, ignore_pos, status_val;
/* 
 * X,Y,Z1,Z2 read commands - control_byte0 
 * select_scan - control_byte1 
 */
	u8 read_x, read_y, read_z1, read_z2, select_scan, read_status, dummy;
/* 
 * Timer data 
 */
	struct timer_list timer;
/* 
 * PENIRQ & function returning Line Status 
 */
	int (*get_pendown_state) (void);
	int penirq;
/* 
 * Power state- Device suspended 
 */
	unsigned disabled:1;
/* 
 * Spin_lock 
 */
	spinlock_t lock;
};


/* 
 * SPI incompletion handler
 *	 Invoked for commands read_x, read_y, read_z1
 * @params:
 *	input:
 *		data: tsc2006_data structure
 *	output:
*/
static void tsc2006_in_complete(void *tsc)
{
	struct tsc2006 *ts = (struct tsc2006 *)tsc;
	struct spi_message *m;
	struct spi_transfer *t;
/*	
 *  msg_idx=0=> read_y, 1=>read_x, 2=>read_z1
 * 	msg_idx=3=>read_z2, msg_idx=6=>Select_scan (if TSC_Mode_2)
 */
	spin_lock_irq(&ts->lock);

	m = &ts->msg[ts->msg_idx];
	t = list_entry(m->transfers.prev, struct spi_transfer, transfer_list);

/* 
 * In TSC_MODE_1, host init-ed mode, the 1st transfer is of the
 * converter function select with msg_id=6, and hence the check
 */
	if (ts->msg_idx == CONV_SEL_SPI_MSG_ID) {
		/* Start read_y now */
		ts->msg_idx = -1;
	} else {
		/* Do nothing */
	}

	++ts->msg_idx;
	m = &ts->msg[ts->msg_idx];

	spin_unlock_irq(&ts->lock);
	/*
	 * Submit the next transfer
	 */
	spi_async(ts->spi_dev, m);
	return;
}

/* 
 * SPI completion handler - called on read_z2 
 * @params:
 *	input:
 *		data: tsc2006_data structure
 *	output:
*/
static void tsc2006_complete(void *tsc)
{
	struct tsc2006 *ts = tsc;
	struct input_dev *ip = ts->input_dev;
	u16 x, y;
	unsigned int touch_pressure = 0;

	spin_lock_irq(&ts->lock);

	if (ts->z1_pos != 0) {
/*
 * Formula - 1 used for Calculation of Touch_Pressure (R-Touch)
 * 450 being XPlate_Resistane - since ADS7846 environment had the same
 */
#ifdef BIT_MODE_12
		touch_pressure =
		    450 * (ts->x_pos / 4096) * (ts->z2_pos / ts->z1_pos - 1);
		touch_pressure = touch_pressure & 0xfff;
#else
		touch_pressure =
		    450 * (ts->x_pos / 1024) * (ts->z2_pos / ts->z1_pos - 1);
		touch_pressure = touch_pressure & 0x3ff;
#endif
	}

	/*
	 * The co-ordinates read from TSC, needs to be mapped to co-ordinates
	 * required by the X-windows (GUI).
	 * In the current scenario we have X, Y axes swapped, & direction
	 * of X also being swapped. 
	 */

#ifdef BIT_MODE_12
/* as tsc Y moves to max, lcd X moves to min */
	x = (4096 - (be16_to_cpu(ts->y_pos) & 0xfff));
	x = (int)(x * LCDX_MAX / 4096);
/* as tsc X moves to max, lcd Y moves to max */
	y = (be16_to_cpu(ts->x_pos) & 0xfff);
	y = (int)(y * LCDY_MAX / 4096);
#else
/* as tsc Y moves to max, lcd X moves to min */
	x = (1024 - (be16_to_cpu(ts->y_pos) & 0x3ff));
	x = (int)(x * LCDX_MAX / 1024);
/* as tsc X moves to max, lcd Y moves to max */
	y = (be16_to_cpu(ts->x_pos) & 0x3ff);
	y = (int)(y * LCDY_MAX / 1024);
#endif

/*
 * Uncomment following line to report Actual Pressure
 * Although not an absolute must, make sure z1, z2 are consitant
 * before uncommenting
 */
/*
 * #define report_actual_pressure
 */

#ifdef report_actual_pressure
	if (touch_pressure)
#endif
	{
		input_report_abs(ip, ABS_X, x);
		input_report_abs(ip, ABS_Y, y);
#ifdef report_actual_pressure
		input_report_abs(ip, ABS_PRESSURE, touch_pressure /*7500 */ );
#elif !defined(PENIRQ_PINTDAV_OUTPUT)
		input_report_abs(ip, ABS_PRESSURE, 7500);
#endif
#if !defined(PENIRQ_PINTDAV_OUTPUT)
		input_report_key(ip, BTN_TOUCH, 1);
		input_sync(ip);
#endif /* PENIRQ_PINTDAV_OUTPUT */
	}
#ifdef report_actual_pressure
	else {
		/* Error Reporting Zero pressure */
	}
#endif

	spin_unlock_irq(&ts->lock);

/*
 * Restart Timer if pendown, else enable_irq which was disabled in
 * the IRQ handler
 */
#ifdef PENIRQ_PINTDAV_OUTPUT
	u16 status_val = be16_to_cpu(ts->status_val) & 0xC000;
	if (likely(!ts->get_pendown_state()) || status_val)
#else /* PENIRQ_PINTDAV_OUTPUT */
	if (likely(!ts->get_pendown_state()))
#endif
	{
#ifdef PENIRQ_PINTDAV_OUTPUT
#ifdef report_actual_pressure
		input_report_abs(ip, ABS_PRESSURE, touch_pressure);
#else
		input_report_abs(ip, ABS_PRESSURE, 7500);
#endif
		input_report_key(ip, BTN_TOUCH, 1);
		input_sync(ip);
#endif /* PENIRQ_PINTDAV_OUTPUT */
		mod_timer(&ts->timer, jiffies + BETWEEN_READS);
	} else {
		enable_irq(ts->penirq);
	}
}				/* end of tsc2006_complete */

/* 
 * The Timer function -
 * 	Submit previously setup SPI transaction here 
 * @params:
 *	input:
 *		data: tsc2006_data structure
 *	output:
*/
static void tsc2006_timer(unsigned long handle)
{
	struct tsc2006 *ts = (void *)handle;
	int status = 0;

	ts->msg_idx = 0;
#ifdef TSC_MODE_2
/* msg_idx=6 contains the converter function select */
	ts->msg_idx = CONV_SEL_SPI_MSG_ID;
#endif
	status = spi_async(ts->spi_dev, &ts->msg[ts->msg_idx]);

	return;
}

/* 
 * IRQ Handler -
 * 	Disable IRQ & detect cause of IRQ (pendown or penup),
 * 	either start the timer or report penup & enable_irq
 * @params:
 *	input:
 *		IRQ - which caused the interrupt, 
 *		data: tsc2006_data structure
 *	output:
 *		IRQ_HANDLED
 */
static irqreturn_t tsc2006_irq(int irq, void *handle)
{
	struct tsc2006 *tsc = handle;
	struct input_dev *ip = tsc->input_dev;
	unsigned long flags = 0;

	spin_lock_irqsave(&tsc->lock, flags);
	disable_irq(irq);

	if (likely(!(tsc->get_pendown_state()))) {
		mod_timer(&tsc->timer, jiffies + ON_IRQ /*HZ*1 */ );
	} else {
		input_report_key(ip, BTN_TOUCH, 0);
		input_report_abs(ip, ABS_PRESSURE, 0);
		input_sync(ip);
		enable_irq(irq);
	}
	spin_unlock_irqrestore(&tsc->lock, flags);
	return IRQ_HANDLED;
}

/*
 *	SPI sync() based calls cannot be executed in Interrupt contexts
 * 	hence the reading of X, Y, Z1 & Z2 co-ordinates require a list
 * 	of SPI transfers setup
 * 	If TSC_MODE_1 is selected, the select_scan message should also
 * 	be a part of that list.
 * 	Delays in function wont affect the performance since the function
 * 	is called only at the initialisation of driver.
 * @params:
 *	input:
 *		data: tsc2006_data structure
 *	output:
 *		function return status
*/
static int tsc2006_spi_setup(struct tsc2006 *ts)
{
	int status;
	unsigned char wr_cmd[3];
	unsigned short cfr0_val;

	struct spi_message *m;
	struct spi_transfer *x;

	cfr0_val = 0;
	status = 0;
	wr_cmd[0] = wr_cmd[1] = wr_cmd[2] = 0;

#ifdef TSC_MODE_2
	/* 0x60 */
	wr_cmd[0] = TSC2006_CMD_CNTRL0(ADDR_CFR0, PND_0, CNTRL_BYTE0_WR);
#ifdef PENIRQ_PINTDAV_OUTPUT
	wr_cmd[1] = 0x00;
	wr_cmd[2] = 0x00;
#else
	wr_cmd[1] = 0x00;
	wr_cmd[2] = 0x1c;
#endif /* PENIRQ_PINTDAV_OUTPUT */
	/* 
	 * PV2-PV0:=000
	 * SN2-SN0:=111; DTW=0; LSM=0
	 * Adjust these values with ON_IRQ & BETWEEN_READ Times
	 * to obtain a good results on drag, draw, click
	 */
	status = spi_write(ts->spi_dev, &wr_cmd[0], 3);
	if (status != 0) {
		goto err_status;
	}
#endif /* end of TSC_MODE_2 */

/*
 * In TSCMode1 send Write for CFR0 to configure in TSC_Mode1
 */
#ifdef TSC_MODE_1
	/* 0x60 */
	wr_cmd[0] = TSC2006_CMD_CNTRL0(ADDR_CFR0, PND_0, CNTRL_BYTE0_WR);
	/* 
	 * Set PSM bit 1 to set TSC in TSC mode
	 */
#ifdef PENIRQ_PINTDAV_OUTPUT
	/* SN2:SN1 = 000 */
	wr_cmd[1] = 0x80;
	wr_cmd[2] = 0x00;
#else
	/* SN2:SN1 = 111 */
	wr_cmd[1] = 0x80;
	wr_cmd[2] = 0x1d;
#endif /* PENIRQ_PINTDAV_OUTPUT */
	/*
	 * Bits in CFR0 
	 * LSM=1 and SN2-SN1 = 111, makes both drawing and clicks just right
	 */
	status = spi_write(ts->spi_dev, &wr_cmd[0], 3);
	if (status != 0) {
		goto err_status;
	}

	/* converter function select XYZ */
	udelay(100);

#ifdef BIT_MODE_12
	wr_cmd[0] = TSC2006_CMD_CNTRL1(SCAN_X_Y_Z1_Z2, RES_12_BIT, SWRST_OFF, STS_STOP);	//0x84;
#else
	wr_cmd[0] = TSC2006_CMD_CNTRL1(SCAN_X_Y_Z1_Z2, RES_10_BIT, SWRST_OFF, STS_STOP);	//0x84;
#endif /* BIT_MODE_12 */

	status = spi_write(ts->spi_dev, &wr_cmd[0], 1);
	if (status != 0) {
		goto err_status;
	}
#endif /* TSC_MODE_1 */

#ifdef PENIRQ_PINTDAV_OUTPUT
/*
 *	In CFR2 set PINTS1:PINTS0 = 10, to output /PENIRQ as /PINTDAV
 */
	wr_cmd[0] = TSC2006_CMD_CNTRL0(ADDR_CFR2, PND_0, CNTRL_BYTE0_WR);
	wr_cmd[1] = 0x02 << 6;
	wr_cmd[2] = 0x00;
	status = spi_write(ts->spi_dev, &wr_cmd[0] /*cfr2=0x80 */ , 3);
	if (status != 0) {
		goto err_status;
	}
	udelay(10);
	wr_cmd[0] = TSC2006_CMD_CNTRL0(ADDR_CFR2, PND_0, CNTRL_BYTE0_RD);
	status = spi_write_then_read(ts->spi_dev, &wr_cmd[0], 1,
				     (u8 *) & cfr0_val, 2);
	if (status != 0) {
		goto err_status;
	}
	if (be16_to_cpu(cfr0_val) != 0x8000) {
		goto err_status;
	}
#endif /* PENIRQ_PINTDAV_OUTPUT */

#ifdef TSC_MODE_2
	m = &ts->msg[CONV_SEL_SPI_MSG_ID];	/* last msg */
	x = &ts->xfer[CONV_SEL_SPI_XFER_ID];	/* last 2 xfers */
/* 
 * In host initiated mode, transfer should include a select_scan
 * command, and should be sent before sending the read, write commands
 */
	spi_message_init(m);
	memset(x, 0, sizeof(*x));

#ifdef BIT_MODE_12
	ts->select_scan =	/*0x80; */
	    TSC2006_CMD_CNTRL1(SCAN_X_Y_Z1_Z2, RES_12_BIT, SWRST_OFF, STS_STOP);
#else
	ts->select_scan =	/*0x80; */
	    TSC2006_CMD_CNTRL1(SCAN_X_Y_Z1_Z2, RES_10_BIT, SWRST_OFF, STS_STOP);
#endif /* BIT_MODE_12 */

	x->tx_buf = &ts->select_scan;
	x->len = 1;
	spi_message_add_tail(x, m);
	m->complete = tsc2006_in_complete;
	m->context = ts;
#endif /*TSC_MODE_2 */

	m = &ts->msg[0];
	x = &ts->xfer[0];
/*0,1 read_y*/
	spi_message_init(m);
	memset(x, 0, sizeof(*x));
	ts->read_y =		/*0x09; */
	    TSC2006_CMD_CNTRL0(ADDR_Y, PND_0, CNTRL_BYTE0_RD);
	x->tx_buf = &ts->read_y;
	x->len = 1;
	spi_message_add_tail(x, m);

	x++;
	memset(x, 0, sizeof(*x));
	x->rx_buf = &ts->y_pos;
	x->len = 2;
	spi_message_add_tail(x, m);

	m->complete = tsc2006_in_complete;
	m->context = ts;
/*2,3 read_x*/
	m++;
	x++;

	spi_message_init(m);
	memset(x, 0, sizeof(*x));
	ts->read_x =		/*0x01; */
	    TSC2006_CMD_CNTRL0(ADDR_X, PND_0, CNTRL_BYTE0_RD);
	x->tx_buf = &ts->read_x;
	x->len = 1;
	spi_message_add_tail(x, m);

	x++;
	memset(x, 0, sizeof(*x));
	x->rx_buf = &ts->x_pos;
	x->len = 2;
	spi_message_add_tail(x, m);

	m->complete = tsc2006_in_complete;
	m->context = ts;
/*4,5 read_z1*/
	m++;
	x++;

	spi_message_init(m);
	memset(x, 0, sizeof(*x));
	ts->read_z1 =		/*0x11; */
	    TSC2006_CMD_CNTRL0(ADDR_Z1, PND_0, CNTRL_BYTE0_RD);
	x->tx_buf = &ts->read_z1;
	x->len = 1;
	spi_message_add_tail(x, m);

	x++;
	memset(x, 0, sizeof(*x));
	x->rx_buf = &ts->z1_pos;
	x->len = 2;
	spi_message_add_tail(x, m);

	m->complete = tsc2006_in_complete;
	m->context = ts;

/*6,7 read_z2*/
	m++;
	x++;

	spi_message_init(m);
	memset(x, 0, sizeof(*x));
	ts->read_z2 =		/*0x19; */
	    TSC2006_CMD_CNTRL0(ADDR_Z2, PND_0, CNTRL_BYTE0_RD);
	x->tx_buf = &ts->read_z2;
	x->len = 1;
	spi_message_add_tail(x, m);

	x++;
	memset(x, 0, sizeof(*x));
	x->rx_buf = &ts->z2_pos;
	x->len = 2;
	spi_message_add_tail(x, m);

	m->complete = tsc2006_complete; /*The last call among transfers */ ;
	m->context = ts;

#ifdef PENIRQ_PINTDAV_OUTPUT

	m->complete = tsc2006_in_complete;
	m->context = ts;
	m++;
	x++;
/*8,9 read_status*/
	spi_message_init(m);
	memset(x, 0, sizeof(*x));
	ts->read_status =
	    TSC2006_CMD_CNTRL0(ADDR_STATUS, PND_0, CNTRL_BYTE0_RD);
	x->tx_buf = &ts->read_status;
	x->len = 1;
	spi_message_add_tail(x, m);

	x++;
	memset(x, 0, sizeof(*x));
	x->rx_buf = &ts->status_val;
	x->len = 2;
	spi_message_add_tail(x, m);

	m->complete = tsc2006_complete; /*The last call among transfers */ ;
	m->context = ts;

#endif /*PENIRQ_PINTDAV_OUTPUT */

	return 0;
      err_status:
	return -1;
}

/*	
 * 	Start of functions which were registered as a
 *	part of tsc2006 spi_driver.
 * 
 *  Should be Called, if the device has been added to list of
 *  SPI devices in board_init. [Even without an actual Slave device]
 * @params:
 *	input:
 *		SPI device structure allocated for the device
 *	output:
 *		function return status
 */
static int __devinit tsc2006_probe(struct spi_device *spi)
{
	struct tsc2006 *ts;
	struct input_dev *input_dev;
	int err;

	/*
	 * Check for Max_speed of SPI bus 
	 */
	if (spi->max_speed_hz > (125000 * SAMPLE_BITS)) {
		dev_dbg(&spi->dev, "f(sample) %d KHz?\n",
			(spi->max_speed_hz / SAMPLE_BITS) / 1000);
		return -EINVAL;
	}

	/* 
	 * Set up the SPI Interface 
	 */
	spi->bits_per_word = 8;
	/*
	 * Refer to TSC Slave device CPOL and CPHA
	 */
	spi->mode = SPI_MODE_0;
	err = spi_setup(spi);
	if (err < 0) {
		return err;
	}

	ts = kzalloc(sizeof(struct tsc2006), GFP_KERNEL);
	input_dev = input_allocate_device();
	if (!ts || !input_dev) {
		err = -ENOMEM;
		goto err_free_mem;
	}

	spin_lock_init(&ts->lock);

	dev_set_drvdata(&spi->dev, ts);
	spi->dev.power.power_state = PMSG_ON;

	ts->spi_dev = spi;
	ts->input_dev = input_dev;

	ts->get_pendown_state = tsc2006_pendown_state;

	input_dev->evbit[0] = BIT_MASK(EV_KEY) | BIT_MASK(EV_ABS);
	input_dev->keybit[BIT_WORD(BTN_TOUCH)] = BIT_MASK(BTN_TOUCH);

	input_set_abs_params(input_dev, ABS_X, 0, LCDX_MAX, 0, 0);
	input_set_abs_params(input_dev, ABS_Y, 0, LCDY_MAX, 0, 0);
	/*
	 * Should Ideally be recieved from platform_data
	 * initialised in board_init.
	 * Have same values of ads7846 since the platform is same
	 */
	input_set_abs_params(input_dev, ABS_PRESSURE, 100, 15000, 0, 0);

	input_dev->name = "TI TSC2006 TouchScreen Controller";
	err = input_register_device(input_dev);
	if (err) {
		goto err_free_mem;
	}
	/*
	 * Initialise TIMER
	 */
	init_timer(&ts->timer);
	ts->timer.data = (unsigned long)ts;
	ts->timer.function = tsc2006_timer;

/*
 * Setup SPI transfers here
 */
	if (tsc2006_spi_setup(ts) != 0) {
		/* 
		 * Perform h/w reset of TSC
		 */
	}

/*
 * Request IRQ here, 
 * ts->penirq should hold the IRQ upon which the TSC shall
 * Interrupt
 */
	ts->penirq = tsc2006_detect_irq();

	if (request_irq(ts->penirq, tsc2006_irq, IRQF_TRIGGER_FALLING,
			spi->dev.driver->name, ts)) {
		dev_dbg(&spi->dev, "irq %d busy?\n", spi->irq);
		err = -EBUSY;
		goto err_free_irq;
	}

	return 0;

      err_free_irq:
	free_irq(ts->penirq, ts);

      err_free_mem:
	input_free_device(input_dev);
	kfree(ts);
	return err;

}

/*	
 *	Remove spi device from the system 
 *	Make sure all interfaces/data structures initialised in _probe
 *	are closed / terminated / freed here
 * @params:
 *	input:
 *		SPI device structure allocated for the device
 *	output:
 *		function return status
 */


static int __devexit tsc2006_remove(struct spi_device *spi)
{
	struct tsc2006 *ts = dev_get_drvdata(&spi->dev);
/*
 * Undo things done in _probe
 */
	input_unregister_device(ts->input_dev);
	free_irq(ts->penirq, ts);
	input_free_device(ts->input_dev);
	del_timer_sync(&ts->timer);
	kfree(ts);

	return 0;
}
static struct spi_driver tsc2006_driver = {

	.driver = {
/*
 * Name: As in board_init function for probe
 */
		   .name = "tsc2006",
		   .bus = &spi_bus_type,
		   .owner = THIS_MODULE,
		   },
	.probe = tsc2006_probe,
	.remove = __devexit_p(tsc2006_remove),
};

/*
 *	Init and the _exit of this driver module
 * 	Register / Un-Register Driver as SPI Protocol Driver 
 */

static int __init tsc2006_init(void)
{
	return spi_register_driver(&tsc2006_driver);
}

module_init(tsc2006_init);

static void __exit tsc2006_exit(void)
{
	spi_unregister_driver(&tsc2006_driver);
}

module_exit(tsc2006_exit);

MODULE_DESCRIPTION("TSC2006 TouchScreen Driver");
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Pavan_Savoy@mindtree.com");
