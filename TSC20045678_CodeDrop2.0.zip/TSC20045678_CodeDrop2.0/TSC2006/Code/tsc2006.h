/*
 *	Driver Header for TI Touch Screen Controller TSC2005/6 
 *	 
 * 
 * TSC Interfaced with Atmel AT91sam9261ek board,
 * with PENIRQ connected to AT91_PIN_PB0 and on
 * SPI0.2 (spi0 chip_select2)
 * modalias: "tsc2006" or "tsc2005"
 * 
 * 
 * Author	: Pavan Savoy (pavan_savoy@mindtree.com)
 * Date		: 15-05-2008
 */

#ifndef TSC200X_H_
#define TSC200X_H_


#include <linux/init.h>
#include <linux/err.h>
#include <linux/delay.h>
#include <linux/input.h>
#include <linux/interrupt.h>
#include <linux/slab.h>
#include <linux/spi/spi.h>

/* Control Byte */
/* control_byte ID */
#define CNTRL_BYTE0	0
#define CNTRL_BYTE1	1

/* C3-C0 */
#define SCAN_X_Y_Z1_Z2	0
#define SCAN_X_Y	1
#define SCAN_X		2
#define SCAN_Y		3
/* 
 * Could continue until 15
 * #define	TURN_ON_X-_Y+	15
 */

/* RM bit */
#define RES_10_BIT	0
#define RES_12_BIT	1

/* SWRST */
#define SWRST_OFF	0
#define SWRST_ON	1

/* STS bit */
#define STS_ABORT	1
#define STS_STOP	0

#define TSC2005_CMD_CNTRL1(scan_foo,rm,swrst,sts)\
( (CNTRL_BYTE1 << 7) | (scan_foo << 3) | (rm << 2) | (swrst << 1) | sts)

#define TSC2006_CMD_CNTRL1(scan_foo,rm,swrst,sts)\
( (CNTRL_BYTE1 << 7) | (scan_foo << 3) | (rm << 2) | (swrst << 1) | sts)


/* Regiser Address */
#define	ADDR_X		0	/*The X register:	0x0*/
#define	ADDR_Y		1	/*The Y register:	0x1*/
#define	ADDR_Z1		2	/*The Z1 register:	0x2*/
#define	ADDR_Z2		3	/*The Z2 register:	0x3*/
#define	ADDR_AUX	4	/*The AUXILLARY register:0x4*/	
#define	ADDR_TEMP1	5	/*The Temparature1 register:	0x5*/
#define	ADDR_TEMP2	6	/*The Temparature2 register:	0x6*/
#define	ADDR_STATUS	7	/*The Status Register:		0x7*/
#define	ADDR_CFR0	12	/*Configuration register 0:	0xC*/
#define	ADDR_CFR1	13	/*Configuration register 1:	0xD*/
#define	ADDR_CFR2	14	/*Configuration register 2:	0xE*/
#define	ADDR_CONV_SEL_STATUS	15	/*Convertor function select register:		0xF*/

/* Power Not Down */
#define PND_0		0
#define PND_ALWAYS_ON	1

/* Data Flow Direction */
#define CNTRL_BYTE0_RD	1
#define CNTRL_BYTE0_WR	0

/* 2nd Bit be 0 always */
#define TSC2005_CMD_CNTRL0(reg_addr,pnd,rd_wr)\
( (CNTRL_BYTE0 << 7) | (reg_addr << 3) | (pnd << 1) | (rd_wr) )


#define TSC2006_CMD_CNTRL0(reg_addr,pnd,rd_wr)\
( (CNTRL_BYTE0 << 7) | (reg_addr << 3) | (pnd << 1) | (rd_wr) )



/* 
 * Configure the TSC to work in TSC initiated and controlled mode
 * or Host-initiated TSC controlled mode
 * This requires the PSM bit in CFR0 register to be set/cleared, 
 * which will be done in tsc2006_spi_setup 
 */  
#define TSC_MODE_2
/*
 * #define TSC_MODE_2
 */

/*
 * Configure the /PINTDAV output as /PENIRQ, if not selected the
 *	default state (in cfr2) would be to output (/PENIRQ & DAV)
 */
//#define PENIRQ_PINTDAV_OUTPUT
/*
 * Configure the TSC to read values in 12 bit resolution.
 * By default TSC is in 10 bit mode. 
 */
/*
 * #define BIT_MODE_12
 */
#define BIT_MODE_12
/* 
 * To check Max Bus frequency of SPI
 */
#define SAMPLE_BITS     (8 /*cmd*/ + 16 /*sample*/ + 2 /* before, after */)

/* 
 * Poll period between 2 samples 
 *	- its the time, driver sleeps between timer func calls
 * Modify BETWEEN_READS for drag /draw events
 * Modify ON_IRQ for click, double click events 
 */
#define BETWEEN_READS 	7 
#define ON_IRQ		5

/*
 * If the PINTDAV output is configured to output the PENIRQ
 * then reduce the times for Timer & IRQ.
 */
#ifdef PENIRQ_PINTDAV_OUTPUT
	#undef BETWEEN_READS
	#undef ON_IRQ
	#define BETWEEN_READS 	3
	#define ON_IRQ		3
#endif
/*
 * Max X, Y axes of LCD screen
 */
#define LCDX_MAX	240
#define LCDY_MAX	320

#ifdef TSC_MODE_1
#if defined(TSC_MODE_2)
	#error Both Modes Defined, Define any one of them
#endif
	#warning TSC configured in Mode controlled & initiated by TSC
#elif defined(TSC_MODE_2)
	#warning TSC configured in Mode controlled by TSC, Initiated by HOST
#else
	#define TSC_MODE_1
	#warning No Mode Defined, working in TSC Mode
#endif

#ifdef BIT_MODE_12
	#warning TSC configured to 12 bit resolution
#endif


/*
 *	SPI transfer macros
 *	In TSC_MODE_2, the select_scan transfer is listed as the 6th
 *		msg & 13th xfer
 */
#define MAX_SPI_XFERS 		15
#define MAX_SPI_MSGS		7
#define CONV_SEL_SPI_MSG_ID	6
#define CONV_SEL_SPI_XFER_ID	13


int tsc2006_pendown_state(void);
int tsc2006_detect_irq(void);

#endif /*TSC200X_H_*/

